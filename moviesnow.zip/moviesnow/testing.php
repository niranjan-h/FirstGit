<!DOCTYPE html>
<html lang="en">
<head>
<title>Spir</title>
<meta charset="utf-8">
<link rel="icon" href="css/images/favicon.ico">
<link rel="shortcut icon" href="css/images/favicon.ico">
<link rel="stylesheet" href="css/css/style.css">
<link rel="stylesheet" href="css/css/camera.css">
<!--[if !IE]>-->
<link rel="stylesheet" href="css/blur.css">
<!--<![endif]-->
<script src="css/js/jquery.js"></script>
<script src="css/js/jquery-migrate-1.1.1.js"></script>
<script src="css/js/superfish.js"></script>
<script src="css/js/jquery.equalheights.js"></script>
<script src="css/js/jquery.easing.1.3.js"></script>
<script src="css/js/jquery.ui.totop.js"></script>
<script src="css/js/camera.js"></script>
<!--[if (gt IE 9)|!(IE)]><!-->
<script src="css/js/jquery.mobile.customized.min.js"></script>
<!--<![endif]-->
<script>
$(document).ready(function () {
    jQuery('#camera_wrap').camera({
        loader: false,
        pagination: false,
        thumbnails: false,
        height: '48.82978723404255%',
        caption: false,
        navigation: true,
        fx: 'mosaic'
    });
});
$(document).ready(function () {
    $().UItoTop({
        easingType: 'easeOutQuart'
    });
});
$(function () {
    var $container = $('#ib-container'),
        $articles = $container.children('article'),
        timeout;
    $articles.on('mouseenter', function (event) {
        var $article = $(this);
        clearTimeout(timeout);
        timeout = setTimeout(function () {
            if ($article.hasClass('active')) return false;
            $articles.not($article.removeClass('blur').addClass('active'))
                .removeClass('active')
                .addClass('blur');
        }, 65);
    });
    $container.on('mouseleave', function (event) {
        clearTimeout(timeout);
        $articles.removeClass('active blur');
    });
});
</script>
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body class="page1">
<header>
  <div class="container_12">
    <div class="grid_12">
      <div class="menu_block">
        <h1><a href="css/index.html"><img src="css/images/logo1.png" alt=""></a> </h1>
        <nav>
          <ul class="sf-menu">
            <li class="current"><a href="css/index.html">Home</a></li>
            <li class="with_ul"><a href="css/nowshowing.html">NOW SHOWING</a>
              <ul>
                <li><a href="css/english.html">ENGLISH</a></li>
                <li><a href="css/hindi.html">HINDI</a></li>
                <li><a href="css/kannada.html">KANNADA</a></li>
                <li><a href="css/telugu.html">TELUGU</a></li>
              </ul>
            </li>
            <li><a href="css/commingsoon.html">COMMING SOON</a>
             <ul>
                <li><a href="css/english.html">ENGLISH</a></li>
                <li><a href="css/hindi.html">HINDI</a></li>
                <li><a href="css/kannada.html">KANNADA</a></li>
                <li><a href="css/telugu.html">TELUGU</a></li>
              </ul>
            </li>
            <li><a href="css/login page.php">RATE</a></li>
          </ul>
        </nav>
        <div class="clear"></div>
      </div>
      <div class="slider_wrapper">
        <div id="camera_wrap">
          <div data-src="images/slide22.jpg"> </div>
          <div data-src="images/slide11.jpg"> </div>
          <div data-src="images/slide.jpg"> </div>
        </div>
      </div>
     
</body>
</html>