-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 12, 2017 at 12:49 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `moviesnow`
--
CREATE DATABASE IF NOT EXISTS `moviesnow` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `moviesnow`;

-- --------------------------------------------------------

--
-- Table structure for table `actor`
--

CREATE TABLE IF NOT EXISTS `actor` (
  `Act_id` int(11) NOT NULL AUTO_INCREMENT,
  `Act_Name` varchar(20) NOT NULL,
  `Act_Gender` varchar(8) NOT NULL,
  PRIMARY KEY (`Act_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=127 ;

--
-- Dumping data for table `actor`
--

INSERT INTO `actor` (`Act_id`, `Act_Name`, `Act_Gender`) VALUES
(101, 'Achyuth kumar', 'Male'),
(102, 'Yash', 'Male'),
(103, 'Srinidhi Ramesh', 'Female'),
(104, 'Puneeth Rajkumar', 'Male'),
(105, 'Rashmika Mandanna', 'Female'),
(106, 'Mukesh Tiwary', 'Male'),
(107, 'Srimuli', 'Male'),
(108, 'Shanvi Srivastav', 'Female'),
(109, 'Devraj', 'Male'),
(110, 'Darshan', 'Male'),
(111, 'Ambarish', 'Male'),
(112, 'V Ravichandran', 'Male'),
(113, 'ShivaRajkumar', 'Male'),
(114, 'Sudeep', 'Male'),
(115, 'Amy Jackson', 'Female'),
(116, 'Srikanth', 'Male'),
(117, 'Dhruva Sarja', 'Male'),
(118, 'Rachita Ram', 'Female'),
(119, 'Srinivas Murthy', 'Male'),
(120, 'Haripriya', 'Female'),
(121, 'Tilak Shekar', 'Male'),
(122, 'Nabha Netesh', 'Female'),
(123, 'Ravi Kale', 'Male'),
(124, 'Sruthi Hariharan', 'Female'),
(125, 'Priya Anand', 'Female'),
(126, 'Prakash Raj', 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `cast`
--

CREATE TABLE IF NOT EXISTS `cast` (
  `Act_id` int(10) NOT NULL DEFAULT '0',
  `Mov_id` int(10) NOT NULL DEFAULT '0',
  `Role` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Act_id`,`Mov_id`),
  KEY `Mov_id` (`Mov_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cast`
--

INSERT INTO `cast` (`Act_id`, `Mov_id`, `Role`) VALUES
(101, 301, 'Villain'),
(102, 301, 'Hero'),
(103, 301, 'Heroine'),
(104, 302, 'Hero'),
(105, 302, 'Heroine'),
(106, 302, 'Villain'),
(107, 303, 'Hero'),
(108, 303, 'Heroine'),
(109, 303, 'Villain'),
(109, 354, 'Ram'),
(110, 304, 'Durydhana'),
(110, 354, 'Tarak'),
(111, 304, 'Bheshma'),
(112, 304, 'Krishna'),
(113, 305, 'Hero'),
(114, 305, 'Hero'),
(115, 305, 'Heroine'),
(116, 305, 'Villain'),
(117, 351, 'Surya'),
(118, 351, 'Gowri'),
(119, 351, 'Villain'),
(124, 354, 'Sneha');

-- --------------------------------------------------------

--
-- Table structure for table `director`
--

CREATE TABLE IF NOT EXISTS `director` (
  `Dir_id` int(11) NOT NULL AUTO_INCREMENT,
  `Dir_Name` varchar(20) NOT NULL,
  `Dir_Phone` double NOT NULL,
  PRIMARY KEY (`Dir_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=364 ;

--
-- Dumping data for table `director`
--

INSERT INTO `director` (`Dir_id`, `Dir_Name`, `Dir_Phone`) VALUES
(311, 'Prashanth Neel', 8861895195),
(312, 'A Harisha', 8861512520),
(313, 'Narthan', 9481473625),
(314, 'Narganna', 9449008330),
(315, 'Prem', 8861521414),
(361, 'Chethan Kumar', 7245362522),
(362, 'Prakash', 9488221254),
(363, 'Santhosh Ananddram', 7212253625);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `repassword` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_id`, `username`, `password`, `repassword`) VALUES
(7, 'aditya', '123', '123'),
(10, 'aditya123', '123', '123'),
(11, 'venk', '123', '123'),
(12, 'arif', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE IF NOT EXISTS `movies` (
  `Mov_id` int(10) NOT NULL AUTO_INCREMENT,
  `Mov_Title` varchar(20) DEFAULT NULL,
  `Mov_Year` int(4) DEFAULT NULL,
  `Mov_Lang` varchar(20) DEFAULT NULL,
  `Mov_Desp` varchar(1000) DEFAULT NULL,
  `Dir_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`Mov_id`),
  UNIQUE KEY `Dir_id` (`Dir_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=355 ;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`Mov_id`, `Mov_Title`, `Mov_Year`, `Mov_Lang`, `Mov_Desp`, `Dir_id`) VALUES
(301, 'KGF', 2017, 'Kannada', 'KGF is an upcoming kannada drama film.[2]The film is written and directed Prashanth Neel and produced by Vijay Kiragandur under the banner Hombale films. It stars Yash and Srinidhi Ramesh Shetty in the lead roles.As of 25 June 2017 the project was 50 percent complete.', 311),
(302, 'Anjani Putra', 2017, 'Kannada', 'Anjani Putra is an upcoming Indian romantic action movie written and directed by A. Harsha, produced by M. N. Kumar and B. Jayashree Devi, and starring Puneeth Rajkumar, Rashmika Mandanna in lead roles, and Haripriya makes a special appears in a song.[1] Anjaniputra is an official remake of Tamil film Poojai.Ravi Basrur had composed the songs and score for the film', 312),
(303, 'Mufti', 2017, 'Kannada', 'Mufti is an upcoming 2017 Kannada action film directed by Narthan making his debut. The film stars Srii Murali and Shanvi Srivastava in lead and Shiva Rajkumar in a pivotal role. Mufti is being produced by the production company Jayanna Combines. The shooting of the movie started July 2016 and the first schedule has been completed.Ravi Basrur has scored music for this movie.', 313),
(304, 'Muniratna kurukshetr', 2018, 'Kannada', 'Muniratna Kurukshetra is an upcoming Indian epic-war Kannada film, written by J. K. Bharavi and directed by Naganna. Produced by Muniratna Naidu, a producer turned MLA, the project is touted to be one of the big budget films in Kannada cinema. The film is loosely based on the Indian epic Mahabharata and poet Rannas Gadhayuddha with the story centred upon Duryodhana, a Kaurava king, played by Darshan.\r\n\r\nBesides Darshan, the film features an ensemble cast including Ambarish, V. Ravichandran, Arjun Sarja, Nikhil Kumar, Sneha, Lakshmi, Saikumar Pudipeddi, Sonu Sood, Srinivasa Murthy, Danish Akhtar Saifi, Ravishankar, Regina Cassandra, Hariprriya among others portraying many important characters of the Mahabharata.The score and soundtrack for the film is by V. Harikrishna whilst the cinematography is by Jayanan Vincent.', 314),
(305, 'The Villain', 2018, 'Kannada', 'The Villain is an upcoming film Kannada-language Indian film directed by Prem and produced by CR.Manohar, starring Shiva Rajkumar, Sudeep, Amy Jackson and Mithun Chakraborty.Director Prem announced new film starring the biggest stars of Kannada films, Shiva Rajkumar and Sudeep in lead roles. The film is about a villager who dreams to become an actor. The film is produced by CR.Manohar and they signed Bollywood actor Mithun Chakraborty in an important role that has been kept as a secret in the beginning, but the news was later leaked to the press.', 315),
(351, 'Bharjari', 2017, 'Kannada', 'Bharjari is a 2017 Indian Kannada romance film written and directed by Chethan Kumar. It stars Dhruva Sarja, Rachita Ram, Hariprriya and Vaishali Deepak in the lead roles. The supporting cast features Sudharani, Srinivasa Murthy and Sai Kumar.The original soundtrack for the film is composed by V. Harikrishna.', 361),
(354, 'Tarak', 2017, 'Kannada', 'Tarak is a 2017 Indian action drama Kannada film directed by Prakash and produced by Dushyanth. It features Darshan, Sruthi Hariharan and Shanvi Srivastava in the lead roles. Devaraj, Kuri Prathap and Sumithra feature in important supporting roles. Whilst the soundtrack and score is by Arjun Janya, the cinematography is by A. V. Krishna Kumar. The first look of the film was released on 30 March 2017.\r\n\r\nThe project marks the first film in the combination of Darshan with Prakash of Milana fame and Darshans 49th film to be released. The filming began on 1 March 2017 in Bengaluru. Further, the shooting took place in Malaysia and for the song sequences, the team moved to Switzerland and Italy.', 362);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `Mov_id` int(10) NOT NULL DEFAULT '0',
  `Rev_Stars` varchar(10) NOT NULL,
  PRIMARY KEY (`Mov_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`Mov_id`, `Rev_Stars`) VALUES
(301, 'NA'),
(302, 'NA'),
(303, 'NA'),
(304, 'NA'),
(305, 'NA'),
(351, '3/5'),
(354, '4/5');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cast`
--
ALTER TABLE `cast`
  ADD CONSTRAINT `cast_ibfk_1` FOREIGN KEY (`Act_id`) REFERENCES `actor` (`Act_id`),
  ADD CONSTRAINT `cast_ibfk_2` FOREIGN KEY (`Mov_id`) REFERENCES `movies` (`Mov_id`);

--
-- Constraints for table `movies`
--
ALTER TABLE `movies`
  ADD CONSTRAINT `movies_ibfk_1` FOREIGN KEY (`Dir_id`) REFERENCES `director` (`Dir_id`);

--
-- Constraints for table `rating`
--
ALTER TABLE `rating`
  ADD CONSTRAINT `rating_ibfk_1` FOREIGN KEY (`Mov_id`) REFERENCES `movies` (`Mov_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
