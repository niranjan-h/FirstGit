<link rel="stylesheet" type="text/css" href="css/flexslider.css" />
	<!-- JS Part Start-->
		<script type="text/javascript" src="js/jquery-1.7.1.min.js"></script>
		<script type="text/javascript" src="js/html5.js"></script>
		<script type="text/javascript" src="js/tabs.js"></script>
		<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
		<script type="text/javascript" src="js/jquery.jcarousel.min.js"></script>
		<script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
		<script type="text/javascript" src="js/custom.js"></script>
		<script type="text/javascript">
		$(window).load(function() {
			$('.flexslider').flexslider();
		});
		</script>
	<!-- JS Part End-->