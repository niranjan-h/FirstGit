------------------------------------------------------------------
SF OLD REPUBLIC v1.1, created by ShyWedge, 1999.
------------------------------------------------------------------

The following TrueType fonts are included:

 - SF Old Republic
 - SF Old Republic, Italic
 - SF Old Republic, Bold
 - SF Old Republic, Bold Italic
 - SF Old Republic SC
 - SF Old Republic SC, Italic
 - SF Old Republic SC, Bold
 - SF Old Republic SC, Bold Italic

v1.1 UPDATES
------------------------------------------------------------------

 - Improved lettering, spacing, and kerning.
 - Includes limited punctuation.
 - Small Caps version has been added.


This font package is Freeware.  If you wish to distribute it,
please include all of the above fonts along with this document
and send me an e-mail to let me know which font you have so I can
inform you of the latest updates.

Thank you for downloading this font package and enjoy!

ShyFonts by ShyWedge, 1999.
------------------------------------------------------------------
Web Site:  http://welcome.to/ShyFonts
E-mail:    ShyWedge@yahoo.com