<?php
mysql_connect('localhost','root','');

mysql_select_db('moviesnow');

$sql="SELECT `Mov_id`, `Mov_Title`, `Mov_Year`, `Mov_Lang`, `Mov_Desp` FROM `movies` WHERE Mov_id=351";
$records=mysql_query($sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title>BHARJARI</title>
</head>
<body>
	<img src="images/bharjari.jpg"> 
<?php
while ($s=mysql_fetch_assoc($records)) {
	echo "<tr>";
	echo "<br>";
	echo "<td>".$s['Mov_id']."</td>";
	echo "<br>";
	echo "<td>".$s['Mov_Title']."</td>";
	echo "<br>";
	echo "<td>".$s['Mov_Year']."</td>";
	echo "<br>";
	echo "<td>".$s['Mov_Lang']."</td>";
	echo "<br>";
	echo "<td>".$s['Mov_Desp']."</td>";
	echo "<br>";
	echo "</tr>";
}
?>

</body>
</html>