<?php
$Name=$_POST['a'];
$Rollno=$_POST['b'];
$Marks=$_POST['c'];
mysql_connect("localhost","root","");
mysql_select_db('colleoge');
mysql_query("insert into college values('$Name','$Rollno','$Marks')");
$result=mysql_query("select * from college");
$row=mysql_num_rows($result);
$col=mysql_num_fields($result);
echo "<br> Number of rows:$row</br>";
echo "Number of columns:$col";
?>
<html>
<body>
<table border="2">
<th>Name</th>
<th>Rollno</th>
<th>Marks</th>
<?php
while($rs=mysql_fetch_array($result))
{ 
echo "<tr><td>$rs[0]</td>";
echo "<td>$rs[1]</td>";
echo "<td>$rs[2]</td></tr>";
}
?>
</table>
</body>
</html>
 
