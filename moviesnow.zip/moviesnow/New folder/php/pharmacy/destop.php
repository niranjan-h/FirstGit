
<?php
$dir="C:\Documents and Settings\All Users\Desktop";
if(is_dir($dir))
{
$i=2;
if($dh=opendir($dir))
{
while(($file=readdir($dh))!=false)
{
$i++;
echo "<br>File name=".$file;
}
echo "<br><b> The number of items present on the desktop are:</b>".$i;
}
}
?>






