<?php
$Username=$_POST['un'];
$Password=$_POST['pass'];
if($Username=="CSE" && $Password=="Nalanda")
{
echo "Your login is successful";
}
else
{
echo "Your login is failed";
}
?>
